# جسر التفريغ — تشغيل الموقع في اليمن عبر سيرفرك VPS

هذا المجلد يركّب على سيرفرك جسرًا (reverse bridge) يفعل ثلاثة أشياء:

1. **يفتح الموقع في اليمن**: المستخدم يدخل على عنوان سيرفرك بدل `web-transcriber.pages.dev` المحجوب، والجسر يمرر كل الطلبات للموقع الحقيقي — بدون سقف زمني (ملفات 100 ميجا وتفريغات طويلة تشتغل).
2. **يخزن الفيديوهات على سيرفرك**: كل ملف يرفعه مستخدم عبر `/api/transcribe-upload` يحفظ نسخة منه في `/opt/transcriber-bridge/uploads` وبنفس الوقت يكمل رفعته للتفريغ.
3. **شهادة HTTPS أوتوماتيكية** عبر Caddy (تجدد نفسها).

## المتطلبات

- VPS بنظام **Debian 11+ أو Ubuntu 20.04+** وعليه صلاحيات root
- المنافذ **80 و 443** مفتوحة من الخارج
- **عنوان دومين يشاور على IP السيرفر** (ضروري لشهادة HTTPS). أسهل خيار مجاني:
  1. افتح https://www.duckdns.org وسجّل دخول بحساب GitHub أو Google
  2. أنشئ دومين فرعي (مثلاً `my-transcriber`) وضع فيه IP سيرفرك
  3. صار عنوانك: `my-transcriber.duckdns.org`
  (لو عندك دوميم خاص أفضل — ضع سجل A يشاور على IP السيرفر)

## خطوات التركيب (3 دقائق)

انسخ محتويات هذا المجلد إلى السيرفر ثم:

```bash
cd transcriber-bridge
sudo bash install.sh my-transcriber.duckdns.org
```

السكربت يركّب Node.js وCaddy تلقائيًا، يشغّل الجسر كخدمة systemd (تشغل نفسها بعد إعادة تشغيل السيرفر)، ويضيف تنظيفًا يوميًا للملفات الأقدم من 14 يوم.

بعد التركيب تأكد:

```bash
curl -I https://my-transcriber.duckdns.org/api/config
```

## خطوات على لوحة كلاودفلير وGoogle (مرة وحدة، لتسجيل الدخول من اليمن)

تسجيل الدخول بحساب Google لازم يعود للمستخدم على **عنوان سيرفرك**، وهذا يحتاج خطوتين من مالك المشروع:

1. **كلاودفلير → web-transcriber → Settings → Environment variables**:
   أضف متغير: `GOOGLE_ALT_REDIRECT_HOSTS` بقيمة `my-transcriber.duckdns.org`
2. **Google Cloud Console → OAuth client**: أضف redirect URI:
   `https://my-transcriber.duckdns.org/api/auth/google/callback`
   بجانب الرابط القديم `https://web-transcriber.pages.dev/api/auth/google/callback`

## ملاحظات تشغيلية

- الملفات المرفوعة تُخزن كما هي على القرص: راقب المساحة بـ `df -h` وعدّل مدة الحذف في `/etc/cron.d/transcriber-bridge-cleanup` (الافتراضي 14 يوم).
- السجلات: `journalctl -u transcriber-bridge -f`
- الجسر يستمع محليًا على 127.0.0.1:8079 فقط — الوصول الخارجي كله عبر Caddy وHTTPS.
- الرفع يعمل بنفس قيود الموقع: حتى 100 ميجا للملف.
- للتجربة من اليمن: افتح `https://my-transcriber.duckdns.org` من شبكة يمنية، سجّل دخول Google، وارفع ملف MP4.
