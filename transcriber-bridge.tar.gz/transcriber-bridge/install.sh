#!/usr/bin/env bash
# transcriber-bridge installer — Debian/Ubuntu VPS.
# Usage:  sudo bash install.sh your-host.duckdns.org
set -euo pipefail

HOST="${1:?Usage: sudo bash install.sh your-host.duckdns.org}"
HOST="$(echo "$HOST" | tr '[:upper:]' '[:lower:]' | tr -d ' /')"
if ! [[ "$HOST" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9-]+)+$ ]]; then
  echo "Invalid host name: $HOST"; exit 1
fi
[[ $EUID -eq 0 ]] || { echo "Run as root (sudo)."; exit 1; }
command -v apt-get >/dev/null || { echo "This installer supports Debian/Ubuntu (apt)."; exit 1; }

APP_DIR=/opt/transcriber-bridge
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "==> Installing system packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl gnupg debian-keyring debian-archive-keyring apt-transport-https ca-certificates

# --- Node.js 20 (needed >= 18) ---
NEED_NODE=1
if command -v node >/dev/null 2>&1; then
  MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
  if [ "$MAJOR" -ge 18 ]; then NEED_NODE=0; echo "==> Node.js $(node -v) already present"; fi
fi
if [ "$NEED_NODE" -eq 1 ]; then
  echo "==> Installing Node.js 20 (NodeSource)"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

# --- Caddy (HTTPS with automatic certificates) ---
if ! command -v caddy >/dev/null 2>&1; then
  echo "==> Installing Caddy"
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | \
    gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | \
    tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  apt-get update -y
  apt-get install -y caddy
else
  echo "==> Caddy already present: $(caddy version)"
fi

echo "==> Deploying bridge files to $APP_DIR"
mkdir -p "$APP_DIR/uploads"
cp "$SCRIPT_DIR/bridge.js" "$APP_DIR/bridge.js"
cp "$SCRIPT_DIR/Caddyfile" "$APP_DIR/Caddyfile"

cat > "$APP_DIR/bridge.env" <<EOF
PORT=8079
UPSTREAM_ORIGIN=https://web-transcriber.pages.dev
UPLOAD_DIR=$APP_DIR/uploads
EOF

echo "==> Installing systemd service"
cat > /etc/systemd/system/transcriber-bridge.service <<EOF
[Unit]
Description=Transcriber bridge (reverse proxy + upload mirror)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/bridge.env
ExecStart=/usr/bin/node $APP_DIR/bridge.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
SyslogIdentifier=transcriber-bridge

[Install]
WantedBy=multi-user.target
EOF

# Caddy needs to know the public host; keep its packaged service unit intact
# and pass the variable through a drop-in.
mkdir -p /etc/systemd/system/caddy.service.d
cat > /etc/systemd/system/caddy.service.d/bridge.conf <<EOF
[Service]
Environment=PUBLIC_HOST=$HOST
EnvironmentFile=-$APP_DIR/caddy.env
EOF
echo "PUBLIC_HOST=$HOST" > "$APP_DIR/caddy.env"

echo "==> Configuring Caddy"
cat > /etc/caddy/Caddyfile <<EOF
{\n\tadmin off\n}\n\nimport $APP_DIR/Caddyfile
EOF

echo "==> Opening firewall ports (80/443) when ufw is active"
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
fi

echo "==> Daily cleanup of stored uploads older than 14 days"
cat > /etc/cron.d/transcriber-bridge-cleanup <<EOF
# Daily at 03:30 — remove bridged uploads older than 14 days.
30 3 * * * root find $APP_DIR/uploads -type f -mtime +14 -delete
EOF
chmod 0644 /etc/cron.d/transcriber-bridge-cleanup

systemctl daemon-reload
systemctl enable --now transcriber-bridge
systemctl restart caddy

echo
echo "==> Done. Status:"
systemctl --no-pager -l status transcriber-bridge | head -n 6 || true
echo
echo "Public address : https://$HOST"
echo "Check it with : curl -I https://$HOST/api/config"
echo "Stored uploads: ls $APP_DIR/uploads   (auto-deleted after 14 days)"
echo "Bridge logs   : journalctl -u transcriber-bridge -f"
