#!/usr/bin/env node
// transcriber-bridge — self-hosted reverse bridge for web-transcriber.pages.dev
//
// Streams every request to the Cloudflare Pages app while:
//   * keeping long transcription responses open (no artificial timeouts),
//   * mirroring uploaded media files to a local uploads directory,
//   * presenting the public host (X-Forwarded-Host) so the app can route
//     Google OAuth logins back through this bridge when the host is
//     allowlisted in GOOGLE_ALT_REDIRECT_HOSTS on the Pages project.
//
// Zero npm dependencies. Requires Node.js >= 18.
"use strict";
const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { PassThrough } = require("stream");

const UPSTREAM = process.env.UPSTREAM_ORIGIN || "https://web-transcriber.pages.dev";
const PORT = Number(process.env.PORT || 8079);
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, "uploads");
const TEE_PATHS = (process.env.TEE_PATHS || "/api/transcribe-upload")
  .split(",").map(s => s.trim()).filter(Boolean);
// Keep-alive agent so the TLS handshake to Cloudflare is not repeated per request.
const agent = new https.Agent({ keepAlive: true, maxSockets: 32 });

const upstreamUrl = new URL(UPSTREAM);
const UP_HOST = upstreamUrl.hostname;
const UP_PORT = upstreamUrl.port ? Number(upstreamUrl.port) : 443;
const UP_ORIGIN = upstreamUrl.origin;

// Hop-by-hop headers are never forwarded in either direction.
const HOP = new Set(["connection", "keep-alive", "proxy-authenticate",
  "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade", "host"]);

function safeName(raw) {
  try { raw = decodeURIComponent(raw || ""); } catch { raw = ""; }
  raw = String(raw).replace(/[\\/\x00-\x1f\x7f]/g, "").trim();
  if (!raw || raw === "." || raw === "..") return "upload.bin";
  return raw.slice(-120);
}

function stamp() {
  const d = new Date(), p = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

const server = http.createServer((clientReq, clientRes) => {
  const publicHost = (clientReq.headers.host || "").toString();
  const upstreamPath = clientReq.url;

  // Upstream header set: keep everything except hop-by-hop, rewrite the
  // origin-scoped headers to the upstream origin, and expose the public
  // host the browser actually talks to.
  const headers = { ...clientReq.headers };
  for (const h of HOP) delete headers[h];
  headers.host = UP_HOST;
  if (typeof headers.origin === "string" && /^https?:\/\//i.test(headers.origin))
    headers.origin = UP_ORIGIN;
  if (typeof headers.referer === "string" && /^https?:\/\//i.test(headers.referer)) {
    try {
      const r = new URL(headers.referer);
      headers.referer = UP_ORIGIN + r.pathname + r.search;
    } catch { delete headers.referer; }
  }
  if (publicHost) headers["x-forwarded-host"] = publicHost;
  headers["x-forwarded-proto"] = "https";

  // Mirror uploaded media to disk while streaming the same bytes upstream.
  const tee = clientReq.method === "POST" &&
    TEE_PATHS.some(p => upstreamPath === p || upstreamPath.startsWith(p + "?")) &&
    !!(clientReq.headers["content-length"] || clientReq.headers["transfer-encoding"]);
  let savedAs = null, fileStream = null;
  let body = clientReq;
  if (tee) {
    const name = safeName(clientReq.headers["x-media-filename"]);
    savedAs = path.join(UPLOAD_DIR, `${stamp()}-${name}`);
    try {
      fs.mkdirSync(UPLOAD_DIR, { recursive: true });
      fileStream = fs.createWriteStream(savedAs);
      fileStream.on("error", err => console.error("[bridge] save error:", err.message));
      body = new PassThrough({ highWaterMark: 1024 * 1024 });
      clientReq.pipe(body);
      clientReq.pipe(fileStream);
    } catch (err) {
      console.error("[bridge] cannot open uploads dir:", err.message);
      fileStream = null; savedAs = null; body = clientReq;
    }
  }

  const upReq = https.request({
    hostname: UP_HOST, port: UP_PORT, method: clientReq.method,
    path: upstreamPath, headers, agent
  }, upRes => {
    const outHeaders = { ...upRes.headers };
    for (const h of HOP) delete outHeaders[h];
    // Keep the browser on the public host: any upstream redirect that
    // points back at the pages.dev origin is rewritten to the bridge.
    if (typeof outHeaders.location === "string" && outHeaders.location.startsWith(UP_ORIGIN))
      outHeaders.location = "https://" + publicHost + outHeaders.location.slice(UP_ORIGIN.length);
    clientRes.writeHead(upRes.statusCode, outHeaders);
    upRes.pipe(clientRes);
    upRes.on("error", () => clientRes.destroy());
  });

  // No artificial timeout: transcription responses legitimately take minutes.
  upReq.setSocketKeepAlive(true, 60000);
  upReq.setTimeout(0);
  upReq.on("error", err => {
    console.error("[bridge] upstream error:", err.message);
    if (!clientRes.headersSent)
      clientRes.writeHead(502, { "Content-Type": "text/plain; charset=utf-8" });
    clientRes.end("bridge: upstream unavailable\n");
  });
  body.pipe(upReq);
  clientReq.on("aborted", () => upReq.destroy());
  clientRes.on("close", () => { if (!clientRes.writableEnded) upReq.destroy(); });

  const started = Date.now();
  clientRes.on("finish", () => {
    const secs = ((Date.now() - started) / 1000).toFixed(1);
    console.log(`${new Date().toISOString()} ${clientReq.method} ${upstreamPath} ${clientRes.statusCode} ${secs}s${savedAs ? " saved=" + savedAs : ""}`);
  });
});

// Large uploads over slow links must not be cut off by Node's default
// request timeout (5 minutes); header timeout stays at its safe default.
server.requestTimeout = 0;
server.headersTimeout = 60000;
server.on("clientError", (err, socket) => socket.end("HTTP/1.1 400 Bad Request\r\n\r\n"));
server.listen(PORT, "127.0.0.1", () =>
  console.log(`[bridge] listening on 127.0.0.1:${PORT} -> ${UP_ORIGIN}, uploads mirror: ${UPLOAD_DIR}`));
